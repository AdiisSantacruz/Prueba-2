archivo=open('ejemplo.txt','r')
texto = archivo.readline()
archivo.close()
numPala = 0

for linea in texto:
    for palabra in linea.split():
        numPala +=1

print ("El numero de palabras en el texto es: " +str(numPala))